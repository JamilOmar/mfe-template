export default () => ({
  title: process.env['API_TITLE'],
});
