module.exports = {
  title: process.env['APP_TITLE'],
  apiUrl: process.env['APP_API_URL'],
};
