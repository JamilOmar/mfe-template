import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-external-entry',
  templateUrl: './entry.component.html',
  styleUrl: './entry.component.scss',
})
export class RemoteEntryComponent implements OnInit {
  ngOnInit() {
    console.log('loaded');
  }
  posts = [
    {
      author: 'Alice',
      content: 'Had a great time hiking today!',
      date: new Date(),
    },
    {
      author: 'Bob',
      content: 'Happy birthday to me!',
      date: new Date('2024-06-01'),
    },
    {
      author: 'Carol',
      content: 'Just moved to a new city!',
      date: new Date('2024-05-20'),
    },
  ];
}
